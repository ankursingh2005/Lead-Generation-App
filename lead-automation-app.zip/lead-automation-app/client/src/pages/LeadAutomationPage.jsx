import React, { useState, useEffect } from "react";
import axios from "axios";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";

export default function LeadAutomationPage() {
  const [leads, setLeads] = useState([]);
  const [formData, setFormData] = useState({ name: "", email: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const submitLead = async () => {
    try {
      await axios.post("http://localhost:5000/api/leads", formData);
      alert("Lead submitted successfully");
      setFormData({ name: "", email: "" });
      fetchLeads();
    } catch (error) {
      alert("Error submitting lead");
    }
  };

  const fetchLeads = async () => {
    const response = await axios.get("http://localhost:5000/api/leads");
    setLeads(response.data);
  };

  useEffect(() => {
    fetchLeads();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold">Automated Lead Generation System</h1>
        <p className="text-gray-600 mt-2">Full-stack system with form submission and storage</p>
      </header>

      <section className="max-w-xl mx-auto bg-white shadow-lg rounded-lg p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Submit New Lead</h2>
        <input
          type="text"
          name="name"
          placeholder="Name"
          className="w-full border p-2 rounded mb-2"
          value={formData.name}
          onChange={handleChange}
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          className="w-full border p-2 rounded mb-4"
          value={formData.email}
          onChange={handleChange}
        />
        <Button onClick={submitLead}>Submit Lead</Button>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {leads.map((lead, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <h3 className="font-bold">{lead.name}</h3>
              <p className="text-sm text-gray-600">{lead.email}</p>
            </CardContent>
          </Card>
        ))}
      </section>
    </div>
  );
}