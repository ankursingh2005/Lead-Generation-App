import React from "react";
import LeadAutomationPage from "./pages/LeadAutomationPage";

function App() {
  return <LeadAutomationPage />;
}

export default App;